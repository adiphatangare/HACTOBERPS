// 6) Hollow Square Pattern: Write a program to print a hollow square pattern using “*”:
// The Pattern is:
//     *
//    * *
//   * * *
//  * * * *