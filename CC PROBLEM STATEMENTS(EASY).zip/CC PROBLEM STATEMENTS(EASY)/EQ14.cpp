// 14) Write one program to perform following operations on strings
// A.	To find length of a string 
// B.	To compare two string for equality
// C.	To Copy one string to other
// D.	To concatenate two string
// E.	To find reverse of a String