// 21) Write a program to Multiply Two 3*3 matrix and find its transpose.
