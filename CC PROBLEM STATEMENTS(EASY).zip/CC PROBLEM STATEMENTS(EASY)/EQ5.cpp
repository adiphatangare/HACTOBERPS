// 5) Write a program to accept a number from user and Display it’s Factorial.
