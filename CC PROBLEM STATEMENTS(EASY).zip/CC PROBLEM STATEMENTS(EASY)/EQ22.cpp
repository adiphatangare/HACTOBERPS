// 22) Write a C++ program to declare a class “staff” having data members name, baic salary, DA, HRA and calculate gross salary. Accept and display data for one staff.
