// 12) Develop a program to find sum of elements of lower triangular matrix of order MxN IN C++
