// 24) Write a program to test whether a given character is a capital or small letter and change small letters to capital letters and vice versa.
