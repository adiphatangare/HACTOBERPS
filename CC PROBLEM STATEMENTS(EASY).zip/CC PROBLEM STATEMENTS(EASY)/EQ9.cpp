// 9) Implement a program that converts temperatures between Celsius and Fahrenheit based on user choice using a switch-case statement.
