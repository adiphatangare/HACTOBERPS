// 23) Write a program to accept a decimal number from user and print its Reverse number.
