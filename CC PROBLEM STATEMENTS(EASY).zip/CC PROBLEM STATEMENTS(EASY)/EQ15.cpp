// 15) Write a program that checks if a given character is a vowel or a consonant using a function.
