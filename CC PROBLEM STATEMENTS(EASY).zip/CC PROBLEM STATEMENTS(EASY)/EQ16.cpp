// 16) Write a program to calculate compound interest given the principal amount, rate, time, and number of times interest is compounded per year.
