// 8) Develop a program that provides feedback messages based on a student's exam score (e.g., "Excellent," "Good," "Needs Improvement") using a switch-case statement. 
