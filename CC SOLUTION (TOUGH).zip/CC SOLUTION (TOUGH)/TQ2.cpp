// 2.Write program in Which Add 10-20 Periodic Table Elements and Add features like Search by Atomic number, Search by Name, Search by Atomic Mass. 
