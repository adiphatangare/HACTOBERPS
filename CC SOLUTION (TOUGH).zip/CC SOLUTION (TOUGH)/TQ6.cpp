// 6.Write a program to create a class Binary that contains one float data member. overload the 4 arithmetic operators. 
