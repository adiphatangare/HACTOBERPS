// 1.Write a program that counts the number of words in a given text file.
