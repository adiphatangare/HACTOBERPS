// 3.Write a program ask to the user to enter file name to encrypt its content. 
