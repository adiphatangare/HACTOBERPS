// 4.Write a Program to read and display Files content. 
