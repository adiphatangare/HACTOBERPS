// 9.Create a program that generates a random password.
