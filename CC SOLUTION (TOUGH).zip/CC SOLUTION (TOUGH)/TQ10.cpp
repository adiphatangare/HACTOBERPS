// 10.Implement a basic text editor with features like open, edit, and save files.
