// 4)	You are given an m x n integer matrix matrix with the following two properties:
// A)Each row is sorted in non-decreasing order.
// B)The first integer of each row is greater than the last integer of the previous row.
// C)Given an integer target, return true if target is in matrix or false otherwise.
// D)You must write a solution in O(log(m * n)) time complexity.