// 2)	Give the input of the head of a linked list, return the list after sorting it in ascending order.
