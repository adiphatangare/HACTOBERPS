// 13)	Given a rows x cols binary matrix filled with 0's and 1's, find the largest rectangle containing only 1's and return its area.
